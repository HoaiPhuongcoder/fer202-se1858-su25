import "./App.css";
import Card from "./components/Card";
import data from "./ListOfOrchids";

function App() {
  return (
    <div className="container mx-auto mt-20">
      <div className="grid grid-cols-3 gap-3">
        {data.map((item) => {
          return (
            <Card
              name={item.name}
              rating={item.rating}
              isSpecial={item.isSpecial}
              isNatural={item.isNatural}
              image={item.image}
              color={item.color}
              numberOfLike={item.numberOfLike}
              origin={item.origin}
              category={item.category}
            />
          );
        })}
      </div>
    </div>
  );
}

export default App;
