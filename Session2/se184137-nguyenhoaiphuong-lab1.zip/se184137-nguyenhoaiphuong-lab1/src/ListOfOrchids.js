const data = [
  {
    id: 1,
    name: "Taichung beauty",
    rating: 5,
    isSpecial: true,
    isNatural: false,
    image:
      "https://img4.thuthuatphanmem.vn/uploads/2021/06/04/hinh-nen-hoa-lan-don-sac-dep-nhat_032303886.jpg",
    color: "white",
    numberOfLike: 192,
    origin: "Taiwan",
    category: "Cattleya",
  },
  {
    id: 2,
    name: "Rose",
    rating: 5,
    isSpecial: false,
    isNatural: true,
    image:
      "https://i.pinimg.com/originals/e4/50/aa/e450aa2bf91b572a2902691d3d1ddb77.jpg",
    color: "red",
    numberOfLike: 10000,
    origin: "USA",
    category: "Rosaceae",
  },
  {
    id: 2,
    name: "Hydrangea",
    rating: 1,
    isSpecial: true,
    isNatural: true,
    image:
      "https://png.pngtree.com/background/20230426/original/pngtree-hydrangea-garden-in-kamijin-picture-image_2482245.jpg",
    color: "blue",
    numberOfLike: 99999999,
    origin: "World",
    category: "Hydrangea",
  },
];

export default data;
